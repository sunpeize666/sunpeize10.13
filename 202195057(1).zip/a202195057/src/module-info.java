/**
 * 
 */
/**
 * 
 */
module a20231013 {
	requires java.desktop;
}